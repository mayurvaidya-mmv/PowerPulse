import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SETTINGS_PATH = path.join(__dirname, "..", "config", "settings.json");

// Fallback hardcoded key (used if settings file has no key)
const FALLBACK_BEARER_TOKEN = "ABSKQmVkcm9ja0FQSUtleS13cXB3LWF0LTU1OTA1MDI0NTU4NjpjQWNnSG9tOUo0azZ5NVdNcU5tZUpuVElkc2QydG9YN2ZpTVZtRDBSQm05LzlXcUpxLzJOYWJsYnJEVT0=";

function getAIConfig() {
  try {
    const raw = fs.readFileSync(SETTINGS_PATH, "utf8");
    const settings = JSON.parse(raw);
    
    // The new logic uses modelId as the single source of truth
    const modelId = settings.ai?.modelId || settings.ai?.bedrockModelId || "anthropic.claude-3-5-sonnet-20240620-v1:0";
    
    // Auto-detect provider based on model ID prefix
    const isOpenAi = modelId.startsWith("gpt-") || modelId.startsWith("o1-");
    const provider = isOpenAi ? "openai" : "bedrock";

    return {
      provider,
      bedrockKey: settings.ai?.bedrockApiKey || FALLBACK_BEARER_TOKEN,
      openaiKey: settings.ai?.openaiApiKey || "",
      modelId,
      maxTokens: settings.ai?.maxTokens || 1000,
      temperature: settings.ai?.temperature ?? 0.4,
    };
  } catch {
    return {
      provider: "bedrock",
      bedrockKey: FALLBACK_BEARER_TOKEN,
      openaiKey: "",
      modelId: "meta.llama3-70b-instruct-v1:0",
      maxTokens: 1000,
      temperature: 0.4,
    };
  }
}

async function callOpenAi(config, systemPrompt, messages) {
  const url = "https://api.openai.com/v1/chat/completions";
  // Convert Bedrock format [{role, content: [{text}]}] to OpenAI [{role, content}]
  const formattedMessages = messages.map(m => ({
    role: m.role,
    content: typeof m.content === "string" ? m.content : (m.content?.[0]?.text || "")
  }));

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${config.openaiKey}`
    },
    body: JSON.stringify({
      model: config.modelId,
      messages: [{ role: "system", content: systemPrompt }, ...formattedMessages],
      max_tokens: config.maxTokens,
      temperature: config.temperature
    })
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`OpenAI Error: ${err}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

async function callBedrock(config, systemPrompt, messages) {
  const url = `https://bedrock-runtime.ap-south-1.amazonaws.com/model/${encodeURIComponent(config.modelId)}/converse`;
  
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${config.bedrockKey}`
    },
    body: JSON.stringify({
      system: [{ text: systemPrompt }],
      messages: messages,
      inferenceConfig: { maxTokens: Math.min(config.maxTokens, 512), temperature: config.temperature, topP: 0.9 }
    })
  });

  if (!response.ok) {
    const err = await response.text();
    throw new Error(`Bedrock Error: ${err}`);
  }

  const data = await response.json();
  return data.output.message.content[0].text;
}

export async function askChatbot(userMessage, chatHistory, contextData) {
  try {
    const config = getAIConfig();
    const ENDPOINT_URL = `https://bedrock-runtime.ap-south-1.amazonaws.com/model/${encodeURIComponent(config.modelId)}/converse`;

    const liveData = contextData.live || contextData;
    const storedData = contextData.stored || { grid: [], generator: [] };

    function summarizeRecords(records) {
      if (!records || records.length === 0) return { available: false };
      const latest = records[0];
      const oldest = records[records.length - 1];
      return {
        available: true,
        recordCount: records.length,
        timeRange: {
          from: oldest?.timestamp || oldest?.sk || "unknown",
          to: latest?.timestamp || latest?.sk || "unknown"
        },
        latestReading: {
          timestamp: latest.timestamp || latest.sk,
          avgVoltage: latest.avgVoltage,
          avgCurrent: latest.avgCurrent,
          avgActivePower: latest.avgActivePower,
          powerFactor: latest.powerFactor,
          frequency: latest.frequency,
          apparentPower: latest.apparentPower,
          voltage: latest.voltage,
          current: latest.current,
        }
      };
    }

    const storedSummary = {
      grid: summarizeRecords(storedData.grid),
      generator: summarizeRecords(storedData.generator)
    };

    const systemPrompt = `You are the PowerPulse AI Assistant, an expert electrical engineer and IoT data analyst.
You help operators understand their power consumption, generator health, and anomalies.

LIVE DATA: ${JSON.stringify(liveData)}
STORED DATA: ${JSON.stringify(storedSummary)}

Use stored data when live data is empty. Be concise. Use Markdown.`;

    const messages = chatHistory || [];
    messages.push({ role: "user", content: [{ text: userMessage }] });

    let finalResponse;
    if (config.provider === "openai") {
      finalResponse = await callOpenAi(config, systemPrompt, messages);
    } else {
      finalResponse = await callBedrock(config, systemPrompt, messages);
    }

    return {
      text: finalResponse,
      updatedHistory: [...messages, { role: "assistant", content: [{ text: finalResponse }] }]
    };
  } catch (error) {
    console.error("❌ AI Assistant Error:", error);
    throw new Error("Failed to process chat request: " + error.message);
  }
}

export async function generateReportSummary(reportData, range, startDate, endDate, customPrompt) {
  try {
    const config = getAIConfig();
    const ENDPOINT_URL = `https://bedrock-runtime.ap-south-1.amazonaws.com/model/${encodeURIComponent(config.modelId)}/converse`;

    const dataSummary = {
      period: reportData.periodDurationStr,
      uptime: reportData.uptimePercent + "%",
      switches: reportData.totalSwitches,
      downtime: reportData.totalDowntimeStr,
      grid: {
        avgPower: (reportData.consumption && reportData.consumption.grid) ? reportData.consumption.grid.avgPower.toFixed(2) + " kW" : "0 kW",
        consumption: (reportData.consumption && reportData.consumption.grid) ? reportData.consumption.grid.kWh + " kWh" : "0 kWh"
      },
      generator: {
        avgPower: (reportData.consumption && reportData.consumption.generator) ? reportData.consumption.generator.avgPower.toFixed(2) + " kW" : "0 kW",
        consumption: (reportData.consumption && reportData.consumption.generator) ? reportData.consumption.generator.kWh + " kWh" : "0 kWh"
      },
      msgPerMin: reportData.messagesPerMin,
      downtimeIncidents: (reportData.downtimePeriods && reportData.downtimePeriods.length) ? reportData.downtimePeriods.length : 0,
    };

    const periodText = (range === 'custom') ? `Custom Range (${startDate} to ${endDate})` : `Last ${range}`;
    
    const defaultSystemPrompt = `You are an expert electrical engineer and AI Analyst for the PowerPulse Dashboard.
Your task is to generate a comprehensive, structured summary of the historical power system data provided.

REQUIREMENTS:
1. Format your response in a highly structured, point-wise layout.
2. Use Markdown tables, bullet points, or figures to present the data clearly if needed.
3. Highlight ANY major abnormal changes, interruptions, downtime, or significant source switching.
4. Include an "Overall Assessment" section.
5. Provide detailed explanations for the metrics but keep it concise and analytical.
6. The output must NOT exceed ${config.maxTokens} tokens.
7. Only output the final markdown report. Do NOT include generic conversational filler like "Here is the summary:"`;

    const systemPrompt = customPrompt || defaultSystemPrompt;

    const userMessage = `Please generate the AI Summary Report for the time range: ${periodText}

REPORT DATA:
${JSON.stringify(dataSummary, null, 2)}`;

    const messages = [{ role: "user", content: [{ text: userMessage }] }];

    let finalResponse;
    if (config.provider === "openai") {
      finalResponse = await callOpenAi(config, systemPrompt, messages);
    } else {
      finalResponse = await callBedrock(config, systemPrompt, messages);
    }

    return finalResponse;
  } catch (error) {
    console.error("❌ Report Summary Error:", error);
    throw new Error("Failed to generate AI report summary: " + error.message);
  }
}
